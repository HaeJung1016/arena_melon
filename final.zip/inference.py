# -*- coding: utf-8 -*-
import final.PlaylistEmbedding as PlaylistEmbedding

FILE_PATH = './'
U_space = PlaylistEmbedding(FILE_PATH)
U_space.run()


